<!--
        Atividade - Banco de Dados
        Ferramenta Auxiliar

        Para está atividade é necessário um ambiente de Localhost.

        Fontes úteis:
            https://www.php.net/docs.php
            https://www.w3schools.com/php/default.asp
-->
<?php

// Função Conectar

// Função Comando SQL

// Função Listar Todos

// Função Listar por Identificador

// Função Deletar

// Função Pesquisar por Palavra-chave


// tools.php