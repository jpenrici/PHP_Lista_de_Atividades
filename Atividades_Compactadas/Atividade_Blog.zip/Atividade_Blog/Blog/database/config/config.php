<?php

/////////////////////////////////////////////////////////////
// Apenas para teste. Dados sensíveis não podem ser expostos!
/////////////////////////////////////////////////////////////

$hostname = "localhost";
$dbname   = "blog_db";
$user     = "admin";
$password = "admin";

$database = [
    'hostname' => $hostname,
    'dbname'   => $dbname,
    'user'     => $user,
    'password' => $password
];

// config.php