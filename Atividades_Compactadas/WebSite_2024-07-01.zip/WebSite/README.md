# WebSite

Este diretório é um modelo básico para a estrutura de um simples Website.<br>
Não existe uma regra específica para organizar e nomear as pastas, modifique quando necessário.<br>

Instale no servidor local e inicie o acesso pela URL:<br>
http://localhost/WebSite/index.html

## Requerimentos

### Aplicativos:

- Apache Server : https://httpd.apache.org/
- PHP : https://www.php.net/
- MySQL : https://www.mysql.com/

### Ambiente de Gestão de Localhost:

- XAMPP : https://www.apachefriends.org/pt_br/index.html
- Wampserver : https://wampserver.aviatechno.net/
- Laragon : https://laragon.org/
