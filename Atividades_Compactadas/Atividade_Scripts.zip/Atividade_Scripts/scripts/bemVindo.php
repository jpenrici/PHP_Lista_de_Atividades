<?php

    $mensagem = "Bem-Vindo!";