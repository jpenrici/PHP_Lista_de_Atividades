<?php

    function bemVindo($nome) {
        return "Bem-Vind, " . $nome . "!";
    }