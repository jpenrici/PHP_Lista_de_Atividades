<?php

    return [
        'theme' => 'dark',
        'autosave' => true
    ];