# WebSite

Pasta reservada para arquivos de configuração que afetam a funcionalidade do Banco de Dados.

## Detalhe

O arquivo ecommerce_db.sql foi gerado automática pelo PhpMyAdmin e tem o objetivo de facilitar os testes.