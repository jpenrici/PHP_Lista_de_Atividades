<!-- Header -->
<div class="header">
    <!-- banner -->
</div>
<!-- Nav Bar -->
<?php
    include "navbar.php";
?>