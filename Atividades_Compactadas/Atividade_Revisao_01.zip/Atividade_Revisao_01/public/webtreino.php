<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Treino : Formulário</title>
</head>

<body>

    <!-- Parte Superior : Formulário -->
    <?php
        require_once "../resources/extra/form.html";
    ?>

    <hr>

    <!-- Parte Inferior : Informações -->
    <p id="info"></p>
    <button onclick="inform()">Teste</button>

    <!-- JavaScript -->
    <script src="../resources/js/info.js"></script>
    
</body>

</html>