# Atividade Calculadora

Está atividade tem o objetivo de reunir grande parte do aprendizado do curso.

Leia com atenção este guia!

Evite ao máximo o uso de chatbots inteligentes, assistentes de código ou copiar soluções prontas.
Desafie-se primeiro, utilize a documentação oficial quando possível.

**Bons estudos!**

## Cenário

A JWC está desenvolvendo um "Website Calculadora PHP" e você deve desenvolver a estrutura, o código e os testes.

## Etapas

1. Crie uma pasta chamada "WebCalc".
2. Crie na pasta "WebCalc" as subpastas "css", "img", "js", "php", "public".
3. Crie na pasta "php" uma subpasta "test".
3. Crie na pasta "WebCalc" um arquivo "index.html" que terá como única função o redirecionamento para o arquivo "webcalc.php".
4. Crie na pasta "public" um arquivo "webcalc.php". O "webcalc.php" deve ter uma página HTML com o título "Web Calc PHP" e executar chamada para os arquivos "header.php", "content.php", "footer.php" usando o comando `require_once`.
5. Crie os arquivos "header.php", "content.php", "footer.php" na pasta "php".
6. Desenvolva os arquivos "header.php" e "footer.php" para embelezar o website que irá conter a calculadora.
7. No arquivo "content.php" faça a chamada para incluir o arquivo "calc.php" que irá servir de "motor de cálculo".
8. Desenvolva a calculadora em "calc.php" que execute: as quatro operações artiméticas e calcule o módulo(resto).
9. Desenvolva na pasta "php/test" arquivos para testar o "calc.php" usando o terminal.
10. Estilize todo o website locando os arquivos ".css" na pasta "css". Utilize imagens, se necessário, e localize na pasta "img".
11. Javascript ...