<?php
    session_start();

    session_destroy();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="0; url=../home.php">
    <title>JWC</title>
</head>

<body>
    <!-- 
        Página apenas para redirecionamento!
    -->
</body>

</html>